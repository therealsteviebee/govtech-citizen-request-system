# Citizen Request Automation System (GovTech Demo)

This project simulates a real-world government service request workflow where a resident submits an issue
such as a pothole, broken streetlight, missed trash pickup, or graffiti report. The system receives the
request, creates a Jira Service Management ticket, and sends a Slack notification to the appropriate team.

## Solution Overview

This demo is designed to showcase:

- workflow automation
- SaaS integrations
- event-driven architecture
- public-sector style service request handling
- a practical Solutions Engineer portfolio project

## Architecture

- **Frontend:** simple HTML request form
- **Backend:** Azure Function (PowerShell, HTTP trigger)
- **Workflow Engine:** Jira Service Management
- **Notifications:** Slack API
- **Documentation:** Markdown workflow notes and architecture diagram

## End-to-End Flow

1. Resident submits a request through the form
2. Azure Function validates and parses the payload
3. Azure Function creates a Jira issue using the Jira REST API
4. Azure Function posts a Slack notification to the operations channel
5. Team tracks and updates the request in Jira

## Repository Structure

```text
govtech-citizen-request-system/
├── README.md
├── .gitignore
├── architecture/
│   └── citizen-request-architecture.svg
├── docs/
│   └── workflow.md
├── samples/
│   └── sample-request.json
└── src/
    └── azure-function/
        ├── function.json
        ├── run.ps1
        ├── profile.ps1
        └── request-form.html
```

## Configuration Required

Set these values in your Azure Function App settings before testing:

- `JIRA_BASE_URL`
- `JIRA_EMAIL`
- `JIRA_API_TOKEN`
- `JIRA_PROJECT_KEY`
- `JIRA_ISSUE_TYPE`
- `SLACK_BOT_TOKEN`
- `SLACK_CHANNEL_ID`

## Notes

- This repo uses placeholder values and is meant to be safe to publish
- Do **not** commit real secrets to GitHub
- The HTML form can be hosted anywhere or used just for demonstration purposes

## Interview Talking Point

> I built a citizen request automation system using Azure Functions, PowerShell, Jira Service Management, and Slack. It demonstrates how public-sector teams can automate request intake, ticket creation, and team notifications using an event-driven workflow.
